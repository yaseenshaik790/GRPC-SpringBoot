package com.sky.skygrpc.repository;

import com.sky.skygrpc.entity.AccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountRepositiry extends JpaRepository<AccountEntity, Integer> {

    AccountEntity findByNumber(Long accountNum);
}
