package com.sky.skygrpc.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "account",schema = "grpc")
public class AccountEntity {

    @Id
    @SequenceGenerator(name = "PERSON_ID_GENERATOR", schema = "cargillag",
            sequenceName = "PERSON_ID_SEQ", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PERSON_ID_GENERATOR")
    @Column(name = "id")
    private Integer id;

    @Column(name = "number")
    private Long number;

    @Column(name = "name")
    private String name;

    @Column(name = "balance")
    private Double balance;
}
