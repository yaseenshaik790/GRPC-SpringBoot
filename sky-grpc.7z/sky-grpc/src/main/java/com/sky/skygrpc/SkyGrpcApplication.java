package com.sky.skygrpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyGrpcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkyGrpcApplication.class, args);
	}

}
