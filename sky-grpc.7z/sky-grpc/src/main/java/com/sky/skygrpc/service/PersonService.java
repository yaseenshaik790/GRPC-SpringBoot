package com.sky.skygrpc.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sky.grpc.PersonRequest;
import com.sky.grpc.PersonResponse;
import com.sky.grpc.PersonServiceGrpc;
import com.sky.skygrpc.entity.PersonEntity;
import com.sky.skygrpc.repository.PersonRepository;
import io.grpc.stub.StreamObserver;
import org.lognet.springboot.grpc.GRpcService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

@GRpcService
public class PersonService extends PersonServiceGrpc.PersonServiceImplBase {

    @Autowired
    private PersonRepository personRepository;

    @Override
    public void savePerson(PersonRequest request, StreamObserver<PersonResponse> responseObserver) {
        PersonEntity personEntity = new PersonEntity();
        //personEntity.setId(request.getPerson().getId());
        personEntity.setName(request.getPerson().getName());
        PersonEntity person = personRepository.save(personEntity);
        PersonResponse personResponse = PersonResponse.newBuilder()
                .setMessage("Person Saved Successfully with as ID: "+person.getId())
                .build();
        responseObserver.onNext(personResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void getPersons(PersonRequest request, StreamObserver<PersonResponse> responseObserver) {

        List<PersonEntity> personEntities = personRepository.findAll();

        StringBuilder sb = new StringBuilder();
        try {
            sb.append(new ObjectMapper().writeValueAsString(personEntities));
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        PersonResponse personResponse = PersonResponse.newBuilder()
                .setMessage(sb.toString()).build();
        responseObserver.onNext(personResponse);
        responseObserver.onCompleted();
    }

    @Override
    public void updatePerson(PersonRequest request, StreamObserver<PersonResponse> responseObserver) {

        Optional<PersonEntity> person = personRepository.findById(request.getPerson().getId());
        if (person.isPresent()){
            PersonEntity personEntity = person.get();
            personEntity.setName(request.getPerson().getName());
            personRepository.save(personEntity);
            PersonResponse personResponse = PersonResponse.newBuilder()
                    .setMessage("Person Updated successfully with ID: "+personEntity.getId()).build();
            responseObserver.onNext(personResponse);
            responseObserver.onCompleted();
        } else {
            responseObserver.onError(new Exception("Invalid Person ID : "+request.getPerson().getId()));
        }
    }
}
