package com.sky.skygrpc.service;

import com.sky.grpc.AccountRequest;
import com.sky.grpc.AccountResponse;
import com.sky.grpc.BankServiceGrpc;
import com.sky.grpc.WithDrawReq;
import com.sky.skygrpc.entity.AccountEntity;
import com.sky.skygrpc.repository.AccountRepositiry;
import io.grpc.stub.StreamObserver;
import lombok.extern.slf4j.Slf4j;
import org.lognet.springboot.grpc.GRpcService;
import org.springframework.beans.factory.annotation.Autowired;

@Slf4j
@GRpcService
public class BankService extends BankServiceGrpc.BankServiceImplBase {

    @Autowired
    private AccountRepositiry accountRepositiry;

    @Override
    public void saveAccount(AccountRequest request, StreamObserver<AccountResponse> responseObserver) {

        AccountEntity accountEntity = new AccountEntity();
        accountEntity.setNumber(request.getAccountNumber());
        accountEntity.setName(request.getAccountName());
        accountEntity.setBalance(request.getBalance());
        AccountEntity account = accountRepositiry.save(accountEntity);
        AccountResponse response = AccountResponse.newBuilder()
                .setMessage("Account Saved Successfully with ID: "+account.getId())
                .build();
        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }

    @Override
    public void balanceWithdraw(WithDrawReq request, StreamObserver<AccountResponse> responseObserver) {

        Long accountNum = request.getAccountNumber();
        double withdrawAmount = request.getAmount();
        for (int i=0; i< (withdrawAmount/10); i++){
            AccountResponse response = AccountResponse.newBuilder()
                    .setMessage("Withdraw Successful and Balance: "+10)
                    .build();
            log.info("balanceWithdraw {} ",10);
            responseObserver.onNext(response);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        responseObserver.onCompleted();
    }
}
