package com.sky.skygrpc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkyGrpcApplicationTests {

	@Test
	void contextLoads() {
	}

}
